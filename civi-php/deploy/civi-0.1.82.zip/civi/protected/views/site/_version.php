Civi Version 0.1.82 vom 01.08.2012 18:25:30
<?php /* NOTE: this file is auto-generated. The digits a and b of the a.b.c version number are kept, c is incremented. */ ?>
